import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import { Player, LobbyState, Question, GameStatus } from "./src/types.js";
import { FALLBACK_QUESTIONS } from "./src/questions.js";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Resolve __dirname in ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json());

// In-memory lobby database
const lobbies = new Map<string, LobbyState>();

// Real-time SSE connections map (lobbyCode -> array of connections)
interface ClientConnection {
  playerId: string;
  res: any;
}
const lobbyConnections = new Map<string, ClientConnection[]>();

// Initialize Gemini client lazily
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== "MY_GEMINI_API_KEY") {
      try {
        aiClient = new GoogleGenAI({
          apiKey: apiKey,
          httpOptions: {
            headers: {
              "User-Agent": "aistudio-build",
            },
          },
        });
        console.log("Successfully initialized server-side Gemini API client.");
      } catch (e) {
        console.error("Failed to initialize Gemini API client:", e);
      }
    } else {
      console.warn("GEMINI_API_KEY environment variable is not configured or is placeholder. Falling back to pre-made trivia.");
    }
  }
  return aiClient;
}

// Helper to shuffle array
function shuffle<T>(array: T[]): T[] {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// Generate random 4-letter room code
function generateRoomCode(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  let code = "";
  for (let i = 0; i < 4; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  // Guarantee uniqueness
  if (lobbies.has(code)) {
    return generateRoomCode();
  }
  return code;
}

// AI Custom Question Generator
async function generateQuestionsWithAI(theme: string, count: number = 4): Promise<Question[]> {
  const ai = getGeminiClient();
  if (!ai) {
    console.log("AI client not available. Using curated fallback questions.");
    return shuffle(FALLBACK_QUESTIONS).slice(0, count);
  }

  try {
    const prompt = `Theme or topic: "${theme}". 
Generate ${count} highly amusing, weird, and engaging Fibbage-style trivia questions based on this theme.
Each question must be a true but bizarre fact with a blank represented by "________".
The correct answer (truth) must be a short, highly specific word or phrase (1-3 words) that fits perfectly into the blank.
Provide 5 to 6 plausible, clever, and funny fallback lies for each question.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are the master question writer for 'Fibbage'. Create questions about bizarre, funny, or surprising facts. Keep categories short (1-2 words). Ensure JSON output matches the requested schema exactly.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              category: { type: Type.STRING, description: "Short category name, e.g. 'Crazy Tech' or 'Dumb Laws'" },
              question: { type: Type.STRING, description: "The trivia question with '________' where the truth belongs" },
              truth: { type: Type.STRING, description: "The correct, surprising true answer" },
              fallbackLies: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "5 or 6 funny, believable lies to pad choices"
              }
            },
            required: ["category", "question", "truth", "fallbackLies"]
          }
        }
      }
    });

    const jsonText = response.text?.trim() || "";
    const generated = JSON.parse(jsonText) as any[];
    
    return generated.map((q, index) => ({
      id: `ai_${Date.now()}_${index}`,
      category: q.category || "General Trivia",
      question: q.question,
      truth: q.truth.trim(),
      fallbackLies: q.fallbackLies || []
    }));
  } catch (error) {
    console.error("Error generating custom questions with Gemini API, falling back:", error);
    return shuffle(FALLBACK_QUESTIONS).slice(0, count);
  }
}

// Broadcast updated state to all connected players in a lobby
function broadcastLobbyState(code: string) {
  const lobby = lobbies.get(code);
  if (!lobby) return;

  const conns = lobbyConnections.get(code) || [];
  const payload = JSON.stringify({ type: "state", data: lobby });

  conns.forEach((conn) => {
    try {
      conn.res.write(`data: ${payload}\n\n`);
    } catch (e) {
      console.error(`Error sending state to player ${conn.playerId} in lobby ${code}:`, e);
    }
  });
}

// Transition from writing to voting
function transitionToVoting(lobby: LobbyState) {
  lobby.status = "voting";
  lobby.timer = 45;
  lobby.maxTimer = 45;

  // Gather and shuffle options for voting
  const currentQuestion = lobby.questions[lobby.currentRoundIndex];
  const allLies = Object.values(lobby.questions[lobby.currentRoundIndex] ? 
    (lobby.players.reduce((acc: string[], p) => {
      // Find what they submitted in previous rounds, wait let's build choices
      return acc;
    }, [])) : []
  );

  // We will build options dynamically in the reveal state
  const uniqueLies = new Set<string>();
  lobby.players.forEach(p => {
    // Only active, non-audience players write lies
    if (!p.isAudience && p.id !== lobby.hostId) {
      // Find if they submitted something
      // We will look up submitted lies in the lobby's active state
    }
  });

  // Keep track of options list
  // Set up reveal state
  const question = lobby.questions[lobby.currentRoundIndex];
  
  // Shuffled lies + truth + fallback padding
  const liesMap = activeLies.get(lobby.code) || {};
  const actualLies = Object.values(liesMap).map(l => l.trim().toLowerCase());
  
  const optionsSet = new Set<string>();
  optionsSet.add(question.truth.toLowerCase());
  
  // Add actual player lies
  Object.values(liesMap).forEach(l => {
    if (l.trim()) {
      optionsSet.add(l.trim().toLowerCase());
    }
  });

  // Add fallback lies to ensure at least 6 options for voting
  let fallbackIndex = 0;
  while (optionsSet.size < 6 && fallbackIndex < question.fallbackLies.length) {
    optionsSet.add(question.fallbackLies[fallbackIndex].toLowerCase());
    fallbackIndex++;
  }

  const optionsArray = Array.from(optionsSet).map(opt => {
    // Match casing with original submission if possible, else capitalize first letter
    if (opt === question.truth.toLowerCase()) return question.truth;
    // Find original lie capitalization
    const original = Object.values(liesMap).find(ol => ol.toLowerCase() === opt);
    if (original) return original;
    // Find fallback lie
    const originalFallback = question.fallbackLies.find(fl => fl.toLowerCase() === opt);
    return originalFallback || opt;
  });

  lobby.revealState = {
    currentRevealedIndex: 0,
    options: shuffle(optionsArray),
    truthOption: question.truth
  };

  // Reset players voted flags
  lobby.players.forEach(p => {
    p.votedThisRound = false;
  });
}

// Active player lies mapping (lobbyCode -> { playerId -> lieText })
const activeLies = new Map<string, { [playerId: string]: string }>();
// Active player votes mapping (lobbyCode -> { playerId -> chosenOption })
const activeVotes = new Map<string, { [playerId: string]: string }>();

// Transition from voting to reveal
function transitionToReveal(lobby: LobbyState) {
  lobby.status = "reveal";
  lobby.timer = 0; // Host controls reveal speed manually or automatic
  
  const question = lobby.questions[lobby.currentRoundIndex];
  const lies = activeLies.get(lobby.code) || {};
  const votes = activeVotes.get(lobby.code) || {};

  // Calculate scores for this round
  lobby.players.forEach(p => {
    p.pointsGainedThisRound = 0;
    p.gotTruth = false;
    p.fooledCount = 0;
  });

  // 1. Process active players and audience votes
  lobby.players.forEach(p => {
    if (p.id === lobby.hostId) return;

    const myVote = votes[p.id];
    if (!myVote) return; // Didn't vote

    const normalizedVote = myVote.trim().toLowerCase();
    const normalizedTruth = question.truth.trim().toLowerCase();

    if (normalizedVote === normalizedTruth) {
      // Guessed the truth!
      p.gotTruth = true;
      if (p.isAudience) {
        p.pointsGainedThisRound += 500;
        p.audienceScore += 500;
      } else {
        p.pointsGainedThisRound += 1000;
        p.score += 1000;
      }
    } else {
      // Guessed a lie! Find who wrote it
      let fooledSomeone = false;
      lobby.players.forEach(liar => {
        if (liar.id === p.id) return; // Can't vote for your own lie
        const liarLie = lies[liar.id];
        if (liarLie && liarLie.trim().toLowerCase() === normalizedVote) {
          fooledSomeone = true;
          liar.fooledCount++;
          // Award points to the liar
          if (p.isAudience) {
            // Fooling audience: +250 points
            liar.pointsGainedThisRound += 250;
            liar.score += 250;
          } else {
            // Fooling active player: +500 points
            liar.pointsGainedThisRound += 500;
            liar.score += 500;
          }
        }
      });
    }
  });

  // Attach lies and votes for reveal client visualization
  if (lobby.revealState) {
    lobby.revealState.lies = lies;
    lobby.revealState.votes = votes;
  }
}

// Transition to Scoreboard
function transitionToScoreboard(lobby: LobbyState) {
  lobby.status = "scoreboard";
  // Reset lies and votes for the next round
  activeLies.set(lobby.code, {});
  activeVotes.set(lobby.code, {});
  
  lobby.players.forEach(p => {
    p.submittedThisRound = false;
    p.votedThisRound = false;
  });
}

// Timer tick loop every 1 second
setInterval(() => {
  for (const [code, lobby] of lobbies.entries()) {
    if (lobby.status === "writing" || lobby.status === "voting") {
      if (lobby.timer > 0) {
        lobby.timer--;
        if (lobby.timer === 0) {
          if (lobby.status === "writing") {
            transitionToVoting(lobby);
          } else if (lobby.status === "voting") {
            transitionToReveal(lobby);
          }
        }
        broadcastLobbyState(code);
      }
    }
  }
}, 1000);

// Keep-alive ping for SSE connections every 10 seconds
setInterval(() => {
  for (const [code, conns] of lobbyConnections.entries()) {
    conns.forEach((conn) => {
      try {
        conn.res.write(": ping\n\n");
      } catch (e) {
        // Dead connection will be cleaned up on close event
      }
    });
  }
}, 10000);

// --- API Endpoints ---

// Create lobby
app.post("/api/lobby/create", async (req, res) => {
  try {
    const { hostName, gameMode, categoryTheme, maxActivePlayers } = req.body;
    const code = generateRoomCode();
    const hostId = "host_" + Math.random().toString(36).substr(2, 9);

    const initialHost: Player = {
      id: hostId,
      name: hostName || "Host",
      score: 0,
      audienceScore: 0,
      isAudience: false,
      connected: true,
      submittedThisRound: false,
      votedThisRound: false,
      fooledCount: 0,
      gotTruth: false,
      pointsGainedThisRound: 0,
    };

    const lobby: LobbyState = {
      code,
      hostId,
      status: "lobby",
      gameMode: gameMode || "classic",
      maxActivePlayers: parseInt(maxActivePlayers) || 8,
      players: [initialHost],
      questions: [],
      currentRoundIndex: 0,
      timer: 0,
      maxTimer: 0,
      categoryTheme: categoryTheme || "General Trivia",
    };

    lobbies.set(code, lobby);
    activeLies.set(code, {});
    activeVotes.set(code, {});

    console.log(`Lobby created: ${code} by ${hostName} (Mode: ${gameMode})`);
    res.json({ success: true, code, hostId, player: initialHost });
  } catch (error) {
    console.error("Lobby creation error:", error);
    res.status(500).json({ error: "Failed to create lobby" });
  }
});

// Join lobby
app.post("/api/lobby/join", (req, res) => {
  try {
    const { code, name } = req.body;
    if (!code || !name) {
      return res.status(400).json({ error: "Room code and name are required." });
    }

    const upperCode = code.toUpperCase().trim();
    const lobby = lobbies.get(upperCode);
    if (!lobby) {
      return res.status(404).json({ error: "Room not found." });
    }

    if (lobby.status !== "lobby") {
      return res.status(400).json({ error: "Game has already started in this room." });
    }

    // Check duplicate name
    const cleanName = name.trim();
    if (lobby.players.some((p) => p.name.toLowerCase() === cleanName.toLowerCase())) {
      return res.status(400).json({ error: "Name is already taken in this room." });
    }

    const playerId = "player_" + Math.random().toString(36).substr(2, 9);
    
    // Determine if player is in the audience
    // Host counts as 1 player, so active players can be up to maxActivePlayers + 1 (with host)
    const activePlayersCount = lobby.players.filter((p) => !p.isAudience && p.id !== lobby.hostId).length;
    const isAudience = lobby.gameMode === "classic" && activePlayersCount >= lobby.maxActivePlayers;

    const newPlayer: Player = {
      id: playerId,
      name: cleanName,
      score: 0,
      audienceScore: 0,
      isAudience,
      connected: true,
      submittedThisRound: false,
      votedThisRound: false,
      fooledCount: 0,
      gotTruth: false,
      pointsGainedThisRound: 0,
    };

    lobby.players.push(newPlayer);
    broadcastLobbyState(upperCode);

    console.log(`Player joined: ${cleanName} to room ${upperCode} (Audience: ${isAudience})`);
    res.json({ success: true, code: upperCode, playerId, player: newPlayer });
  } catch (error) {
    console.error("Join error:", error);
    res.status(500).json({ error: "Failed to join room" });
  }
});

// SSE Event Stream for a room
app.get("/api/lobby/:code/events", (req, res) => {
  const code = req.params.code.toUpperCase().trim();
  const playerId = req.query.playerId as string;

  const lobby = lobbies.get(code);
  if (!lobby) {
    return res.status(404).json({ error: "Lobby not found" });
  }

  // Set SSE Headers
  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
  });

  // Send initial connection confirm
  res.write(`data: ${JSON.stringify({ type: "connected" })}\n\n`);

  // Track connection
  const conn: ClientConnection = { playerId, res };
  if (!lobbyConnections.has(code)) {
    lobbyConnections.set(code, []);
  }
  lobbyConnections.get(code)!.push(conn);

  // Mark player as connected
  const player = lobby.players.find((p) => p.id === playerId);
  if (player) {
    player.connected = true;
    broadcastLobbyState(code);
  }

  // Clean up on disconnect
  req.on("close", () => {
    const conns = lobbyConnections.get(code) || [];
    lobbyConnections.set(code, conns.filter((c) => c !== conn));

    const p = lobby.players.find((pl) => pl.id === playerId);
    if (p) {
      p.connected = false;
      broadcastLobbyState(code);
    }
  });
});

// Post player/host actions
app.post("/api/lobby/:code/action", async (req, res) => {
  const code = req.params.code.toUpperCase().trim();
  const { playerId, actionType, payload } = req.body;

  const lobby = lobbies.get(code);
  if (!lobby) {
    return res.status(404).json({ error: "Lobby not found" });
  }

  const isHost = lobby.hostId === playerId;
  const player = lobby.players.find((p) => p.id === playerId);

  if (!isHost && !player) {
    return res.status(403).json({ error: "Unauthorized player" });
  }

  try {
    switch (actionType) {
      case "start-game": {
        if (!isHost) return res.status(403).json({ error: "Only host can start the game" });
        
        lobby.status = "writing";
        lobby.currentRoundIndex = 0;
        
        // Reset player scores
        lobby.players.forEach(p => {
          p.score = 0;
          p.audienceScore = 0;
          p.submittedThisRound = false;
          p.votedThisRound = false;
        });

        // Generate questions (classic or custom theme with Gemini)
        let questions: Question[] = [];
        if (lobby.categoryTheme && lobby.categoryTheme !== "General Trivia" && lobby.categoryTheme !== "Curated Fallbacks") {
          questions = await generateQuestionsWithAI(lobby.categoryTheme, 4);
        } else {
          questions = shuffle(FALLBACK_QUESTIONS).slice(0, 4);
        }

        lobby.questions = questions;
        lobby.timer = 60;
        lobby.maxTimer = 60;

        activeLies.set(code, {});
        activeVotes.set(code, {});

        broadcastLobbyState(code);
        return res.json({ success: true });
      }

      case "submit-lie": {
        if (lobby.status !== "writing") {
          return res.status(400).json({ error: "Not in writing phase" });
        }
        if (player?.isAudience) {
          return res.status(400).json({ error: "Audience players do not submit lies" });
        }

        const liesMap = activeLies.get(code) || {};
        const cleanedLie = (payload?.lieText || "").trim();

        // Check if matching the real truth (that's illegal, you can't submit the truth!)
        const currentQuestion = lobby.questions[lobby.currentRoundIndex];
        if (cleanedLie.toLowerCase() === currentQuestion.truth.toLowerCase()) {
          return res.status(400).json({ error: "That's the actual TRUTH! Submit a believable lie instead." });
        }

        liesMap[playerId] = cleanedLie;
        activeLies.set(code, liesMap);

        if (player) {
          player.submittedThisRound = true;
        }

        // Check if all active non-host players submitted
        const activePlayers = lobby.players.filter(p => !p.isAudience && p.id !== lobby.hostId);
        const allSubmitted = activePlayers.every(p => p.submittedThisRound);

        if (allSubmitted) {
          transitionToVoting(lobby);
        }

        broadcastLobbyState(code);
        return res.json({ success: true });
      }

      case "submit-vote": {
        if (lobby.status !== "voting") {
          return res.status(400).json({ error: "Not in voting phase" });
        }

        const votesMap = activeVotes.get(code) || {};
        votesMap[playerId] = payload?.optionText || "";
        activeVotes.set(code, votesMap);

        if (player) {
          player.votedThisRound = true;
        }

        // Check if all players (active and connected audience) voted
        const votingPlayers = lobby.players.filter(p => p.id !== lobby.hostId && p.connected);
        const allVoted = votingPlayers.every(p => p.votedThisRound);

        if (allVoted) {
          transitionToReveal(lobby);
        }

        broadcastLobbyState(code);
        return res.json({ success: true });
      }

      case "reveal-next": {
        if (!isHost) return res.status(403).json({ error: "Only host can control the reveal" });
        if (lobby.status !== "reveal" || !lobby.revealState) {
          return res.status(400).json({ error: "Not in reveal phase" });
        }

        const maxIndex = lobby.revealState.options.length;
        if (lobby.revealState.currentRevealedIndex < maxIndex) {
          lobby.revealState.currentRevealedIndex++;
        } else {
          // Finished all option reveals, transition to scoreboard
          transitionToScoreboard(lobby);
        }

        broadcastLobbyState(code);
        return res.json({ success: true });
      }

      case "next-round": {
        if (!isHost) return res.status(403).json({ error: "Only host can advance the round" });
        
        lobby.currentRoundIndex++;
        if (lobby.currentRoundIndex < lobby.questions.length) {
          // Start next round
          lobby.status = "writing";
          lobby.timer = 60;
          lobby.maxTimer = 60;
          lobby.players.forEach(p => {
            p.submittedThisRound = false;
            p.votedThisRound = false;
          });
          activeLies.set(code, {});
          activeVotes.set(code, {});
        } else {
          // Out of questions, game over!
          lobby.status = "gameover";
        }

        broadcastLobbyState(code);
        return res.json({ success: true });
      }

      case "restart-game": {
        if (!isHost) return res.status(403).json({ error: "Only host can restart the game" });
        
        lobby.status = "lobby";
        lobby.currentRoundIndex = 0;
        lobby.questions = [];
        lobby.players.forEach(p => {
          p.score = 0;
          p.audienceScore = 0;
          p.submittedThisRound = false;
          p.votedThisRound = false;
        });

        broadcastLobbyState(code);
        return res.json({ success: true });
      }

      default:
        return res.status(400).json({ error: "Unknown action type" });
    }
  } catch (error) {
    console.error("Action handler error:", error);
    res.status(500).json({ error: "An error occurred while processing action" });
  }
});

// Express start server & Vite dev middleware logic
async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();

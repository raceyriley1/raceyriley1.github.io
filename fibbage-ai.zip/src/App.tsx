import React, { useState, useEffect, useRef } from 'react';
import { LogOut, Laptop, Sparkles, HelpCircle, ShieldAlert } from 'lucide-react';
import { motion } from 'motion/react';

// Type imports
import { LobbyState, Player } from './types.js';

// Component imports
import WelcomeScreen from './components/WelcomeScreen.js';
import LobbyWaiting from './components/LobbyWaiting.js';
import WritingPhase from './components/WritingPhase.js';
import VotingPhase from './components/VotingPhase.js';
import RevealPhase from './components/RevealPhase.js';
import ScoreboardPhase from './components/ScoreboardPhase.js';
import GameOverPhase from './components/GameOverPhase.js';

export default function App() {
  const [code, setCode] = useState<string | null>(null);
  const [playerId, setPlayerId] = useState<string | null>(null);
  const [lobby, setLobby] = useState<LobbyState | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const sseSourceRef = useRef<EventSource | null>(null);

  // Synchronize browser document title
  useEffect(() => {
    if (lobby) {
      document.title = `Fibbage AI - Room ${lobby.code}`;
    } else {
      document.title = "Fibbage AI - Out-Fib Your Friends!";
    }
  }, [lobby]);

  // Clean up SSE on unmount
  useEffect(() => {
    return () => {
      if (sseSourceRef.current) {
        sseSourceRef.current.close();
      }
    };
  }, []);

  // Automatic Session Recovery on startup
  useEffect(() => {
    const savedCode = localStorage.getItem("fib_code");
    const savedPlayerId = localStorage.getItem("fib_player_id");
    if (savedCode && savedPlayerId) {
      setCode(savedCode);
      setPlayerId(savedPlayerId);
      connectSSE(savedCode, savedPlayerId);
    }
  }, []);

  // Setup Server-Sent Events listener
  const connectSSE = (roomCode: string, pId: string) => {
    if (sseSourceRef.current) {
      sseSourceRef.current.close();
    }

    const sse = new EventSource(`/api/lobby/${roomCode}/events?playerId=${pId}`);
    sseSourceRef.current = sse;

    sse.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === "state") {
          setLobby(payload.data);
          setError(null);
        }
      } catch (e) {
        console.error("Error parsing real-time events:", e);
      }
    };

    sse.onerror = (err) => {
      console.error("SSE connection error, room might have expired:", err);
      // If we disconnect during lobby setup, clear cache and reset
      setError("Lost connection to game room. Attempting to reconnect...");
    };
  };

  // REST API: Create lobby
  const handleCreateLobby = async (
    hostName: string,
    gameMode: 'classic' | 'chaos',
    theme: string,
    maxPlayers: number
  ) => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch("/api/lobby/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ hostName, gameMode, categoryTheme: theme, maxActivePlayers: maxPlayers }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to create lobby");
      }

      setCode(data.code);
      setPlayerId(data.player.id);
      setLobby(data.lobby);
      
      localStorage.setItem("fib_code", data.code);
      localStorage.setItem("fib_player_id", data.player.id);
      
      connectSSE(data.code, data.player.id);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred.");
    } finally {
      setLoading(false);
    }
  };

  // REST API: Join lobby
  const handleJoinLobby = async (roomCode: string, name: string) => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch("/api/lobby/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: roomCode, name }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to join room");
      }

      setCode(data.code);
      setPlayerId(data.playerId);
      
      localStorage.setItem("fib_code", data.code);
      localStorage.setItem("fib_player_id", data.playerId);
      
      connectSSE(data.code, data.playerId);
    } catch (err: any) {
      setError(err.message || "Could not join that room.");
    } finally {
      setLoading(false);
    }
  };

  // REST API: Disconnect/Quit
  const handleLeaveLobby = () => {
    if (sseSourceRef.current) {
      sseSourceRef.current.close();
      sseSourceRef.current = null;
    }
    setCode(null);
    setPlayerId(null);
    setLobby(null);
    setError(null);
    localStorage.removeItem("fib_code");
    localStorage.removeItem("fib_player_id");
  };

  // Dispatch player actions to Express backend
  const sendAction = async (actionType: string, payload?: any) => {
    if (!code || !playerId) return;
    try {
      setLoading(true);
      const res = await fetch(`/api/lobby/${code}/action`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ playerId, actionType, payload }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Action failed");
      } else {
        setError(null);
      }
    } catch (err) {
      setError("Failed to coordinate action with server.");
    } finally {
      setLoading(false);
    }
  };

  // Determine current player role
  const isHost = lobby?.hostId === playerId;
  const myPlayer = lobby?.players.find((p) => p.id === playerId);

  // Core Game State Router
  const renderGameContent = () => {
    if (!lobby || !playerId) {
      return (
        <WelcomeScreen
          onCreateLobby={handleCreateLobby}
          onJoinLobby={handleJoinLobby}
          error={error || undefined}
          loading={loading}
        />
      );
    }

    switch (lobby.status) {
      case 'lobby':
        return (
          <LobbyWaiting
            lobby={lobby}
            playerId={playerId}
            onStartGame={() => sendAction("start-game")}
            loading={loading}
          />
        );
      case 'writing':
        return (
          <WritingPhase
            lobby={lobby}
            playerId={playerId}
            onSubmitLie={(lieText) => sendAction("submit-lie", { lieText })}
            loading={loading}
            error={error || undefined}
          />
        );
      case 'voting':
        return (
          <VotingPhase
            lobby={lobby}
            playerId={playerId}
            onVote={(optionText) => sendAction("submit-vote", { optionText })}
            loading={loading}
          />
        );
      case 'reveal':
        return (
          <RevealPhase
            lobby={lobby}
            playerId={playerId}
            onRevealNext={() => sendAction("reveal-next")}
            loading={loading}
          />
        );
      case 'scoreboard':
        return (
          <ScoreboardPhase
            lobby={lobby}
            playerId={playerId}
            onNextRound={() => sendAction("next-round")}
            loading={loading}
          />
        );
      case 'gameover':
        return (
          <GameOverPhase
            lobby={lobby}
            playerId={playerId}
            onRestartGame={() => sendAction("restart-game")}
            loading={loading}
          />
        );
      default:
        return (
          <div className="text-center p-8 bg-zinc-900 border border-zinc-800 rounded-2xl shadow-xl">
            <ShieldAlert className="mx-auto text-rose-500 mb-2" size={32} />
            <h3 className="text-lg font-bold">Unknown Game State</h3>
            <button onClick={handleLeaveLobby} className="mt-4 bg-indigo-600 hover:bg-indigo-500 px-4 py-2 rounded-xl text-xs font-bold text-white transition-all shadow-[0_0_15px_rgba(79,70,229,0.3)]">
              Back to Menu
            </button>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col justify-between py-6 px-4 selection:bg-indigo-500/20 antialiased font-sans">
      
      {/* Global Room Header */}
      {lobby && (
        <header className="w-full max-w-2xl mx-auto flex items-center justify-between bg-zinc-900/50 border border-zinc-800 py-3 px-5 rounded-2xl mb-4 shadow-xl">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center font-bold text-md text-white shadow-[0_0_15px_rgba(79,70,229,0.4)] select-none">F</div>
            <div>
              <span className="text-sm font-black text-white tracking-tighter uppercase block">
                FIBBAGE <span className="text-indigo-500 font-bold">AI</span>
              </span>
              <p className="text-[9px] text-zinc-500 uppercase tracking-widest font-bold">
                {lobby.maxActivePlayers} Player Room
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-right">
              <span className="text-[8px] text-zinc-500 uppercase tracking-widest block font-bold">Room Code</span>
              <span className="text-md font-black text-white tracking-widest font-mono">{lobby.code}</span>
            </div>
            <div className="h-6 w-[1px] bg-zinc-800"></div>
            <button
              onClick={handleLeaveLobby}
              className="flex items-center gap-1.5 text-xs font-extrabold text-zinc-400 hover:text-rose-400 hover:bg-rose-500/10 py-1.5 px-3 rounded-lg transition-all duration-200 cursor-pointer"
            >
              <LogOut size={13} />
              Leave
            </button>
          </div>
        </header>
      )}

      {/* Main Container */}
      <main className="flex-1 flex items-center justify-center py-4">
        {renderGameContent()}
      </main>

      {/* Global Footer */}
      <footer className="text-center text-[9px] text-zinc-500 font-bold uppercase tracking-widest mt-6">
        Fibbage AI • {lobby ? `ROOM ${lobby.code}` : 'Out-Fib Your Friends'} • Screen Synchronized Party Experience
      </footer>
    </div>
  );
}

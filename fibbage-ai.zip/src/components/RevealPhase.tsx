import React from 'react';
import { Eye, HelpCircle, Award, Frown, Sparkles, AlertCircle, Play, ArrowRight, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { LobbyState, Player } from '../types.js';

interface RevealPhaseProps {
  lobby: LobbyState;
  playerId: string;
  onRevealNext: () => void;
  loading?: boolean;
}

export default function RevealPhase({ lobby, playerId, onRevealNext, loading }: RevealPhaseProps) {
  const isHost = lobby.hostId === playerId;
  const myPlayer = lobby.players.find((p) => p.id === playerId);
  
  const currentQuestion = lobby.questions[lobby.currentRoundIndex];
  const revealState = lobby.revealState;

  if (!currentQuestion || !revealState) {
    return <div className="text-center py-8 text-slate-400">Loading reveal board...</div>;
  }

  const { currentRevealedIndex, options, truthOption } = revealState;
  const liesMap = (revealState.lies || {}) as { [playerId: string]: string };
  const votesMap = (revealState.votes || {}) as { [playerId: string]: string };
  const isFinished = currentRevealedIndex >= options.length;

  // The active option being revealed (if not finished)
  const currentOption = !isFinished ? options[currentRevealedIndex] : '';

  // Find who voted for this option
  const votersForCurrentOption = Object.entries(votesMap)
    .filter(([_, votedOption]) => votedOption.toLowerCase() === currentOption.toLowerCase())
    .map(([voterId, _]) => lobby.players.find((p) => p.id === voterId))
    .filter((p): p is Player => !!p);

  // Find who wrote this option (is it a player's lie?)
  const authorOfCurrentOption = Object.entries(liesMap)
    .find(([_, lieText]) => lieText.toLowerCase() === currentOption.toLowerCase())
    ?.[0];
  const authorPlayer = authorOfCurrentOption ? lobby.players.find((p) => p.id === authorOfCurrentOption) : null;

  const isCurrentOptionTruth = currentOption.toLowerCase() === truthOption.toLowerCase();
  const isCurrentOptionHouseLie = !isCurrentOptionTruth && !authorPlayer;

  // Personalized player states
  const wroteCurrentOption = authorOfCurrentOption === playerId;
  const votedForCurrentOption = votesMap[playerId]?.toLowerCase() === currentOption.toLowerCase();

  return (
    <div className="w-full max-w-2xl mx-auto bg-zinc-900 border border-zinc-800 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden text-zinc-100">
      {/* Ambient backgrounds */}
      <div className="absolute top-0 right-1/4 w-72 h-72 bg-violet-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-72 h-72 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex justify-between items-center mb-6 relative z-10 border-b border-zinc-800/80 pb-4">
        <div className="px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-black tracking-widest uppercase">
          REVEAL PHASE • {currentQuestion.category}
        </div>
        <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">
          Option {Math.min(currentRevealedIndex + 1, options.length)} of {options.length}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!isFinished ? (
          <motion.div
            key={currentRevealedIndex}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            transition={{ duration: 0.3 }}
            className="space-y-6 relative z-10"
          >
            {/* The Option in Giant Display Typography */}
            <div className="bg-zinc-950 border border-zinc-850 rounded-2xl p-8 text-center shadow-inner relative overflow-hidden">
              <div className="absolute top-2 left-2 text-[10px] text-zinc-650 font-mono font-bold uppercase tracking-widest select-none">
                VOTING OPTION
              </div>
              <h3 className="text-3xl md:text-4xl font-serif font-normal text-indigo-300 tracking-wide">
                "{currentOption}"
              </h3>
            </div>

            {/* Step 1: Who Voted For This? */}
            <div className="p-5 rounded-2xl bg-zinc-950/40 border border-zinc-850 space-y-3 shadow-inner">
              <h4 className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 flex items-center gap-1.5">
                <Users size={14} className="text-zinc-650" />
                Voters ({votersForCurrentOption.length})
              </h4>
              {votersForCurrentOption.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {votersForCurrentOption.map((p) => (
                    <span
                      key={p.id}
                      className="px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm font-bold text-zinc-300 flex items-center gap-1.5 shadow-sm"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]" />
                      {p.name}
                    </span>
                  ))}
                </div>
              ) : (
                <p className="text-[10px] text-zinc-650 font-black uppercase tracking-widest">No one fell for this one!</p>
              )}
            </div>

            {/* Step 2: Who Created/Wrote It? (The Reveal!) */}
            <div className="p-6 rounded-2xl bg-zinc-950 border border-zinc-850 text-center space-y-4 shadow-xl">
              <div className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                WHICH REVEALS IT WAS...
              </div>

              {isCurrentOptionTruth ? (
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-lg font-black tracking-widest uppercase animate-pulse">
                    <Sparkles size={18} /> THE TRUTH!
                  </div>
                  <p className="text-xs text-zinc-400 leading-relaxed max-w-sm mx-auto">
                    Guessing players gained <span className="text-emerald-400 font-bold">+1000 points</span>! (Audience gained +500)
                  </p>
                </div>
              ) : authorPlayer ? (
                <div className="space-y-2 animate-fadeIn">
                  <div className="text-xs text-zinc-500">A clever lie written by:</div>
                  <div className="text-2xl font-black text-rose-400 tracking-wide uppercase">
                    {authorPlayer.name}!
                  </div>
                  <p className="text-xs text-zinc-450 leading-relaxed max-w-sm mx-auto">
                    {authorPlayer.name} earned <span className="text-rose-400 font-bold">+500 points</span> for every player fooled, and <span className="text-rose-400 font-bold">+250</span> from audience players!
                  </p>
                </div>
              ) : (
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-zinc-800 border border-zinc-750 text-zinc-400 text-[10px] font-bold uppercase tracking-wider">
                    <AlertCircle size={12} /> A HOUSE LIE
                  </div>
                  <p className="text-xs text-zinc-550">No players get points for choosing this decoy.</p>
                </div>
              )}
            </div>

            {/* Personalized Player Feedback Box */}
            {!isHost && (
              <div className="p-4 rounded-xl border border-dashed border-zinc-800 text-center text-sm font-medium">
                {wroteCurrentOption ? (
                  <div className="text-emerald-400 font-bold flex items-center justify-center gap-1.5">
                    <Sparkles size={16} /> YOUR LIE! You fooled {votersForCurrentOption.length} players! Gained points!
                  </div>
                ) : votedForCurrentOption ? (
                  isCurrentOptionTruth ? (
                    <div className="text-emerald-400 font-bold flex items-center justify-center gap-1.5">
                      <Award size={16} /> YOU FOUND THE TRUTH! +{myPlayer?.isAudience ? 500 : 1000} points!
                    </div>
                  ) : (
                    <div className="text-rose-400 font-bold flex items-center justify-center gap-1.5">
                      <Frown size={16} /> YOU GOT FOOLED! {authorPlayer ? `Fell for ${authorPlayer.name}'s lie.` : 'Fell for a decoy.'}
                    </div>
                  )
                ) : (
                  <div className="text-zinc-550 font-black uppercase tracking-widest text-xs">
                    You were safe on this option.
                  </div>
                )}
              </div>
            )}
          </motion.div>
        ) : (
          /* ALL OPTIONS REVEALED SUMMARY */
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-8 space-y-6 relative z-10"
          >
            <Eye className="mx-auto text-indigo-400 animate-pulse" size={48} />
            <h3 className="text-3xl font-black text-white">Reveal Complete!</h3>
            <p className="text-zinc-400 text-sm max-w-md mx-auto leading-relaxed font-medium">
              All lies and options have been successfully unveiled. Let's see how the points stack up on the scoreboard!
            </p>

            <div className="p-5 rounded-2xl bg-zinc-950 border border-zinc-850 space-y-2 shadow-inner">
              <div className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">The actual truth was:</div>
              <div className="text-2xl font-serif text-emerald-400 tracking-wide font-normal">
                {truthOption}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Host Controls */}
      <div className="border-t border-zinc-800/85 mt-6 pt-6 relative z-10">
        {isHost ? (
          <button
            onClick={onRevealNext}
            disabled={loading}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 px-6 rounded-2xl transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/20 animate-fadeIn"
          >
            {isFinished ? 'Show Scoreboard' : 'Reveal Next Option'}
            <ArrowRight size={18} />
          </button>
        ) : (
          <div className="text-center p-3.5 bg-zinc-950/40 rounded-xl border border-zinc-850/50 text-xs text-zinc-500 font-bold uppercase tracking-wider animate-pulse">
            {isFinished ? 'Waiting for host to load scoreboard...' : 'Watch the main screen for the reveal!'}
          </div>
        )}
      </div>
    </div>
  );
}

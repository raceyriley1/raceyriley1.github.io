import React from 'react';
import { Award, Crown, ArrowRight, Shield, Sparkles, AlertCircle, Play } from 'lucide-react';
import { motion } from 'motion/react';
import { LobbyState } from '../types.js';

interface ScoreboardPhaseProps {
  lobby: LobbyState;
  playerId: string;
  onNextRound: () => void;
  loading?: boolean;
}

export default function ScoreboardPhase({ lobby, playerId, onNextRound, loading }: ScoreboardPhaseProps) {
  const isHost = lobby.hostId === playerId;
  const isLastRound = lobby.currentRoundIndex >= lobby.questions.length - 1;

  // Split into Active and Audience leaderboards
  // Host does not have points unless they want to play, let's filter host out or show them at 0
  const activeLeaderboard = lobby.players
    .filter((p) => !p.isAudience && p.id !== lobby.hostId)
    .sort((a, b) => b.score - a.score);

  const audienceLeaderboard = lobby.players
    .filter((p) => p.isAudience && p.id !== lobby.hostId)
    .sort((a, b) => b.audienceScore - a.audienceScore);

  const topPlayer = activeLeaderboard[0];

  return (
    <div className="w-full max-w-2xl mx-auto bg-zinc-900 border border-zinc-800 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden text-zinc-100">
      {/* Decorative ambient gradients */}
      <div className="absolute top-0 right-1/4 w-72 h-72 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="text-center mb-8 relative z-10">
        <div className="px-3 py-1 inline-flex rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-black tracking-widest uppercase mb-2">
          Round {lobby.currentRoundIndex + 1} of {lobby.questions.length} Complete
        </div>
        <h2 className="text-4xl font-black text-white tracking-tighter uppercase">LOBBY STANDINGS</h2>
        <p className="text-sm text-zinc-400 mt-1">See who lied best and who found the truth!</p>
      </div>

      {/* Top Standings / Leader Accent */}
      {topPlayer && topPlayer.score > 0 && (
        <div className="mb-6 bg-zinc-950 p-4 rounded-2xl border-2 border-indigo-500/40 flex items-center justify-between relative z-10 shadow-[0_0_20px_rgba(79,70,229,0.15)] animate-fadeIn">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-indigo-600/10 border border-indigo-500/40 rounded-xl flex items-center justify-center text-amber-400 shadow-inner">
              <Crown size={24} className="animate-bounce" />
            </div>
            <div>
              <div className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest">Current Leader</div>
              <div className="text-lg font-black text-white uppercase">{topPlayer.name}</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest">Score</div>
            <div className="text-2xl font-black text-indigo-400">{topPlayer.score}</div>
          </div>
        </div>
      )}

      {/* Dual Leaderboards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 relative z-10">
        {/* Active Writers Leaderboard */}
        <div className="space-y-3 animate-fadeIn">
          <h3 className="text-xs font-black uppercase tracking-widest text-zinc-400 flex items-center gap-1.5 border-b border-zinc-800 pb-2">
            <Award size={14} className="text-indigo-400" />
            Active Writers
          </h3>
          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
            {activeLeaderboard.map((p, idx) => (
              <div
                key={p.id}
                className="bg-zinc-950/80 border border-zinc-850 p-3 rounded-xl flex items-center justify-between shadow-sm"
              >
                <div className="flex items-center gap-2.5 truncate">
                  <span className="text-xs font-black text-zinc-650 font-mono w-4">
                    #{idx + 1}
                  </span>
                  <span className="text-sm font-bold text-zinc-200 truncate uppercase">
                    {p.name}
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {p.pointsGainedThisRound > 0 && (
                    <span className="text-[10px] font-black bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-1.5 py-0.5 rounded shadow-sm">
                      +{p.pointsGainedThisRound}
                    </span>
                  )}
                  <span className="text-sm font-black text-white w-14 text-right font-mono">
                    {p.score}
                  </span>
                </div>
              </div>
            ))}
            {activeLeaderboard.length === 0 && (
              <div className="text-center text-xs text-zinc-600 font-bold py-4 uppercase">
                No active writers
              </div>
            )}
          </div>
        </div>

        {/* Audience Leaderboard */}
        <div className="space-y-3 animate-fadeIn">
          <h3 className="text-xs font-black uppercase tracking-widest text-zinc-400 flex items-center gap-1.5 border-b border-zinc-800 pb-2">
            <Sparkles size={14} className="text-amber-500" />
            Audience Trophy ({audienceLeaderboard.length})
          </h3>
          <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
            {audienceLeaderboard.map((p, idx) => (
              <div
                key={p.id}
                className="bg-zinc-950/50 border border-zinc-850 p-3 rounded-xl flex items-center justify-between shadow-sm"
              >
                <div className="flex items-center gap-2.5 truncate">
                  <span className="text-xs font-bold text-zinc-650 font-mono w-4">
                    #{idx + 1}
                  </span>
                  <span className="text-sm font-medium text-zinc-350 truncate uppercase">
                    {p.name}
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {p.pointsGainedThisRound > 0 && (
                    <span className="text-[9px] font-bold bg-amber-500/10 border border-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded shadow-sm">
                      +{p.pointsGainedThisRound}
                    </span>
                  )}
                  <span className="text-sm font-bold text-zinc-100 w-14 text-right font-mono">
                    {p.audienceScore}
                  </span>
                </div>
              </div>
            ))}
            {audienceLeaderboard.length === 0 && (
              <div className="p-4 rounded-xl bg-zinc-950/25 border border-zinc-850/30 text-center text-[10px] text-zinc-500 font-medium italic leading-relaxed">
                Connect more than {lobby.maxActivePlayers} devices to see audience players compete in their own leaderboard here!
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="border-t border-zinc-800/85 pt-6 relative z-10">
        {isHost ? (
          <button
            onClick={onNextRound}
            disabled={loading}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 px-6 rounded-2xl transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/20 animate-fadeIn"
          >
            {isLastRound ? 'See Final Winners!' : 'Start Next Round'}
            <ArrowRight size={18} />
          </button>
        ) : (
          <div className="text-center p-3.5 bg-zinc-950/40 rounded-xl border border-zinc-850/50 text-xs text-zinc-500 font-bold uppercase tracking-wider animate-pulse">
            Waiting for the host to load the {isLastRound ? 'final podium' : 'next round'}...
          </div>
        )}
      </div>
    </div>
  );
}

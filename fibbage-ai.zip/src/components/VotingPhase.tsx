import React from 'react';
import { HelpCircle, CheckCircle, Clock, Users } from 'lucide-react';
import { motion } from 'motion/react';
import { LobbyState } from '../types.js';

interface VotingPhaseProps {
  lobby: LobbyState;
  playerId: string;
  onVote: (optionText: string) => void;
  loading?: boolean;
}

export default function VotingPhase({ lobby, playerId, onVote, loading }: VotingPhaseProps) {
  const isHost = lobby.hostId === playerId;
  const myPlayer = lobby.players.find((p) => p.id === playerId);
  const myPlayerVoted = myPlayer?.votedThisRound || false;

  const currentQuestion = lobby.questions[lobby.currentRoundIndex];
  const revealState = lobby.revealState;

  // Find my lie if I am an active writer
  const activeWriters = lobby.players.filter((p) => !p.isAudience && p.id !== lobby.hostId);
  const myVote = myPlayer?.votedThisRound || false;

  // Let's count progress
  const votingPlayers = lobby.players.filter((p) => p.id !== lobby.hostId && p.connected);
  const votesCount = votingPlayers.filter((p) => p.votedThisRound).length;

  if (!currentQuestion || !revealState) {
    return <div className="text-center py-8 text-slate-400">Loading voting board...</div>;
  }

  // Format the question
  const parts = currentQuestion.question.split("________");

  const handleVoteSelect = (option: string) => {
    if (loading || myPlayerVoted) return;
    onVote(option);
  };

  return (
    <div className="w-full max-w-2xl mx-auto bg-zinc-900 border border-zinc-800 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden text-zinc-100">
      {/* Decorative timer indicator */}
      <div className="absolute top-0 left-0 h-1 bg-indigo-500 transition-all duration-1000" style={{ width: `${(lobby.timer / lobby.maxTimer) * 100}%` }} />

      {/* Header and Timer */}
      <div className="flex justify-between items-center mb-6 relative z-10">
        <div className="px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-black tracking-widest uppercase">
          VOTING ROUND • {currentQuestion.category}
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-800 text-amber-500 font-mono text-sm font-black">
          <Clock size={14} className="animate-pulse" />
          {lobby.timer}s
        </div>
      </div>

      {/* The Question Card */}
      <div className="bg-zinc-950 border border-zinc-850 rounded-2xl p-6 md:p-8 text-center mb-8 relative z-10 shadow-inner">
        <h2 className="text-xl md:text-2xl font-serif text-zinc-100 leading-relaxed tracking-wide font-normal">
          {parts[0]}
          <span className="inline-block px-4 py-1 bg-zinc-900/80 border border-dashed border-zinc-700 text-zinc-500 rounded-xl font-mono text-xs md:text-sm mx-1.5 align-middle select-none">
            ????????
          </span>
          {parts[1]}
        </h2>
      </div>

      {/* Player Voting Options / Host Progress View */}
      <div className="relative z-10">
        {isHost ? (
          /* HOST VIEW */
          <div className="space-y-6">
            <div className="text-center mb-4">
              <p className="text-sm text-zinc-400 font-medium">All players are voting on the correct answer!</p>
              <h3 className="text-3xl font-black text-indigo-400 mt-1">
                {votesCount} / {votingPlayers.length} Votes Submitted
              </h3>
            </div>

            <div className="border-t border-zinc-800/80 pt-4">
              <h4 className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-3 flex items-center gap-1.5">
                <Users size={12} className="text-indigo-400" /> Voter Status
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {votingPlayers.map((p) => (
                  <div
                    key={p.id}
                    className={`p-3 rounded-xl border flex items-center justify-between ${
                      p.votedThisRound
                        ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                        : 'bg-zinc-950 border-zinc-850 text-zinc-400'
                    }`}
                  >
                    <span className="text-sm font-bold truncate">{p.name}</span>
                    {p.votedThisRound ? (
                      <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded uppercase font-black">
                        Voted
                      </span>
                    ) : (
                      <span className="text-[9px] bg-zinc-800 text-zinc-500 px-2 py-0.5 rounded uppercase font-medium animate-pulse">
                        Choosing...
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : myPlayerVoted ? (
          /* VOTED/WAITING SCREEN FOR PLAYERS */
          <div className="text-center p-8 bg-zinc-950 rounded-2xl border border-emerald-500/10 space-y-4 shadow-inner animate-fadeIn">
            <CheckCircle className="mx-auto text-emerald-400 animate-bounce" size={40} />
            <h3 className="text-lg font-black text-white">Your Guess is Locked In!</h3>
            <p className="text-sm text-zinc-400 max-w-md mx-auto">
              Nice job! Now let's see how many other players got tricked by player lies, and who managed to find the actual truth.
            </p>
            <div className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">
              Waiting for other players... ({votesCount} / {votingPlayers.length} voted)
            </div>
          </div>
        ) : (
          /* ACTIVE VOTING CARDS GRID */
          <div className="space-y-4 animate-fadeIn">
            <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest text-center">
              Tap the card you believe is the absolute TRUTH:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {revealState.options.map((option, idx) => (
                <button
                  key={idx}
                  onClick={() => handleVoteSelect(option)}
                  disabled={loading}
                  className="w-full text-left bg-zinc-950 hover:bg-indigo-950/20 border border-zinc-800 hover:border-indigo-500/50 p-4 rounded-2xl shadow-lg transition-all duration-200 group active:scale-[0.98] cursor-pointer hover:shadow-[0_0_15px_rgba(79,70,229,0.15)]"
                >
                  <div className="flex justify-between items-center gap-3">
                    <span className="font-bold text-md text-white group-hover:text-indigo-300 transition-colors">
                      {option}
                    </span>
                    <HelpCircle size={16} className="text-zinc-700 group-hover:text-indigo-400 shrink-0 transition-colors" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { PenTool, CheckCircle, Clock, Users, ArrowRight, Eye } from 'lucide-react';
import { motion } from 'motion/react';
import { LobbyState } from '../types.js';

interface WritingPhaseProps {
  lobby: LobbyState;
  playerId: string;
  onSubmitLie: (lieText: string) => void;
  loading?: boolean;
  error?: string;
}

export default function WritingPhase({ lobby, playerId, onSubmitLie, loading, error }: WritingPhaseProps) {
  const [lieText, setLieText] = useState('');
  const isHost = lobby.hostId === playerId;
  const myPlayer = lobby.players.find((p) => p.id === playerId);
  const isAudience = myPlayer?.isAudience || false;
  
  const currentQuestion = lobby.questions[lobby.currentRoundIndex];
  
  // Calculate writing progress
  const activeWriters = lobby.players.filter((p) => !p.isAudience && p.id !== lobby.hostId);
  const submittedCount = activeWriters.filter((p) => p.submittedThisRound).length;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lieText.trim() || loading) return;
    onSubmitLie(lieText.trim());
  };

  if (!currentQuestion) {
    return <div className="text-center py-8 text-slate-400">Loading trivia...</div>;
  }

  // Format the question beautifully to highlight the blank
  const parts = currentQuestion.question.split("________");

  return (
    <div className="w-full max-w-2xl mx-auto bg-zinc-900 border border-zinc-800 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden text-zinc-100">
      {/* Decorative timer indicator */}
      <div className="absolute top-0 left-0 h-1 bg-indigo-500 transition-all duration-1000" style={{ width: `${(lobby.timer / lobby.maxTimer) * 100}%` }} />

      {/* Header and Timer */}
      <div className="flex justify-between items-center mb-6 relative z-10">
        <div className="px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-black tracking-widest uppercase">
          Round {lobby.currentRoundIndex + 1} of {lobby.questions.length} • {currentQuestion.category}
        </div>
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-800 text-amber-500 font-mono text-sm font-black">
          <Clock size={14} className="animate-pulse" />
          {lobby.timer}s
        </div>
      </div>

      {/* The Question Card */}
      <div className="bg-zinc-950 border border-zinc-850 rounded-2xl p-6 md:p-8 text-center mb-8 relative z-10 shadow-inner">
        <h2 className="text-xl md:text-2xl font-serif text-zinc-100 leading-relaxed tracking-wide font-normal">
          {parts[0]}
          <span className="inline-block px-4 py-1.5 bg-indigo-950/80 border border-indigo-900/60 text-indigo-400 rounded-xl font-mono text-xs md:text-sm mx-1.5 align-middle select-none shadow-[0_0_15px_rgba(79,70,229,0.2)] font-black tracking-widest">
            WRITE LIE HERE
          </span>
          {parts[1]}
        </h2>
      </div>

      {/* Player Inputs / Host View / Audience View */}
      <div className="relative z-10">
        {isHost ? (
          /* HOST SCREEN VIEW */
          <div className="space-y-6">
            <div className="text-center mb-4">
              <p className="text-sm text-zinc-400 font-medium">Lobby Players are writing their lies...</p>
              <h3 className="text-3xl font-black text-indigo-400 mt-1">
                {submittedCount} / {activeWriters.length} Submissions
              </h3>
            </div>

            <div className="border-t border-zinc-800/85 pt-4">
              <h4 className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-3 flex items-center gap-1.5">
                <Users size={12} className="text-indigo-400" /> Writer Progress
              </h4>
              <div className="grid grid-cols-2 gap-2">
                {activeWriters.map((p) => (
                  <div
                    key={p.id}
                    className={`p-3 rounded-xl border flex items-center justify-between ${
                      p.submittedThisRound
                        ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                        : 'bg-zinc-950 border-zinc-850 text-zinc-400'
                    }`}
                  >
                    <span className="text-sm font-bold truncate">{p.name}</span>
                    {p.submittedThisRound ? (
                      <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded uppercase font-black">
                        Ready
                      </span>
                    ) : (
                      <span className="text-[9px] bg-zinc-800 text-zinc-500 px-2 py-0.5 rounded uppercase font-medium animate-pulse">
                        Writing...
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : isAudience ? (
          /* AUDIENCE VIEW */
          <div className="text-center p-6 bg-zinc-950 rounded-2xl border border-zinc-850 space-y-4 shadow-inner">
            <Eye className="mx-auto text-amber-500 animate-pulse" size={32} />
            <h3 className="text-lg font-black text-white">You're in the Audience!</h3>
            <p className="text-sm text-zinc-400 max-w-md mx-auto leading-relaxed">
              Audience players do not submit lies, keeping the board clean. Get ready to vote on what you think the true answer is and earn Audience points!
            </p>
            <div className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">
              {submittedCount} of {activeWriters.length} players have submitted
            </div>
          </div>
        ) : myPlayer?.submittedThisRound ? (
          /* SUBMITTED/WAITING VIEW */
          <div className="text-center p-8 bg-zinc-950 rounded-2xl border border-emerald-500/10 space-y-4 shadow-inner animate-fadeIn">
            <CheckCircle className="mx-auto text-emerald-400 animate-bounce" size={40} />
            <h3 className="text-lg font-black text-white">Lie Submitted Successfully!</h3>
            <p className="text-sm text-zinc-400 max-w-md mx-auto">
              Your lie has been sent to the main board. Let's see if anyone is gullible enough to vote for it!
            </p>
            <div className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">
              Waiting for remaining players... ({submittedCount} / {activeWriters.length} submitted)
            </div>
          </div>
        ) : (
          /* ACTIVE WRITER INPUT VIEW */
          <form onSubmit={handleSubmit} className="space-y-4 animate-fadeIn">
            {error && (
              <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs text-center font-bold">
                ⚠️ {error}
              </div>
            )}
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-2">
                Write a believable Lie:
              </label>
              <input
                type="text"
                value={lieText}
                onChange={(e) => setLieText(e.target.value.slice(0, 40))}
                placeholder="Make it sound real..."
                required
                disabled={loading}
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-indigo-500 rounded-2xl py-4 px-5 text-lg font-bold text-white placeholder-zinc-800 outline-none transition-all duration-200 shadow-inner"
              />
            </div>

            <button
              type="submit"
              disabled={loading || !lieText.trim()}
              className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-black py-4 px-6 rounded-2xl transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/20"
            >
              {loading ? 'Submitting...' : 'Submit Lie'}
              <ArrowRight size={18} />
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

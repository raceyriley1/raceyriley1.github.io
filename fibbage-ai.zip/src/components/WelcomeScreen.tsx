import React, { useState } from 'react';
import { Sparkles, Users, User, ArrowRight, Play, Settings } from 'lucide-react';
import { motion } from 'motion/react';

interface WelcomeScreenProps {
  onCreateLobby: (hostName: string, gameMode: 'classic' | 'chaos', theme: string, maxPlayers: number) => void;
  onJoinLobby: (code: string, name: string) => void;
  error?: string;
  loading?: boolean;
}

const PRESET_THEMES = [
  { id: 'General Trivia', name: '🌍 General Curated', desc: 'A hand-crafted set of classic, mind-boggling truths.' },
  { id: 'Weird History', name: '📜 Bizarre History', desc: 'Ridiculous historic occurrences that actually happened.' },
  { id: 'Crazy Tech & Inventions', name: '💾 Tech Fails', desc: 'Unbelievable inventions and software blunders.' },
  { id: 'Dumb Laws', name: '⚖️ Absurd Laws', desc: 'Dumb, outdated, or crazy statutes from around the world.' },
];

export default function WelcomeScreen({ onCreateLobby, onJoinLobby, error, loading }: WelcomeScreenProps) {
  const [activeTab, setActiveTab] = useState<'join' | 'create'>('join');
  const [playerName, setPlayerName] = useState('');
  const [roomCode, setRoomCode] = useState('');
  
  const [hostName, setHostName] = useState('');
  const [gameMode, setGameMode] = useState<'classic' | 'chaos'>('classic');
  const [selectedTheme, setSelectedTheme] = useState('General Trivia');
  const [customTheme, setCustomTheme] = useState('');
  const [maxPlayers, setMaxPlayers] = useState(8);

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!roomCode.trim() || !playerName.trim()) return;
    onJoinLobby(roomCode.toUpperCase().trim(), playerName.trim());
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!hostName.trim()) return;
    const finalTheme = selectedTheme === 'custom' ? customTheme : selectedTheme;
    onCreateLobby(hostName.trim(), gameMode, finalTheme || 'General Trivia', maxPlayers);
  };

  return (
    <div className="w-full max-w-lg mx-auto bg-zinc-900 border border-zinc-800 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden text-zinc-100">
      {/* Decorative ambient gradients */}
      <div className="absolute top-0 left-1/4 w-72 h-72 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-72 h-72 bg-violet-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="text-center mb-8 relative z-10">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-black uppercase tracking-widest mb-3"
        >
          <Sparkles size={14} className="animate-pulse" />
          40 Player Room Lobby Ready
        </motion.div>
        <h1 className="text-5xl font-black tracking-tighter uppercase text-white mb-2">
          FIBBAGE <span className="text-indigo-500 font-bold">AI</span>
        </h1>
        <p className="text-zinc-400 text-sm font-medium">
          Out-fib your friends in this game of lies, trivia, and deception!
        </p>
      </div>

      {/* Tab Switcher */}
      <div className="flex bg-zinc-950 p-1.5 rounded-2xl border border-zinc-850 mb-6 relative z-10">
        <button
          onClick={() => setActiveTab('join')}
          className={`flex-1 py-3 text-sm font-bold rounded-xl transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'join'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/35'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <User size={16} />
          Join Room
        </button>
        <button
          onClick={() => setActiveTab('create')}
          className={`flex-1 py-3 text-sm font-bold rounded-xl transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer ${
            activeTab === 'create'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/35'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          <Play size={16} />
          Create Room
        </button>
      </div>

      {error && (
        <div className="p-4 mb-6 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-sm text-center font-medium">
          {error}
        </div>
      )}

      {/* Tab Content */}
      <div className="relative z-10">
        {activeTab === 'join' ? (
          <form onSubmit={handleJoin} className="space-y-4">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-2">
                Room Code
              </label>
              <input
                type="text"
                value={roomCode}
                onChange={(e) => setRoomCode(e.target.value.toUpperCase().slice(0, 4))}
                placeholder="ENTER 4-LETTER CODE"
                required
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-indigo-500 rounded-2xl py-4 px-5 text-center text-2xl font-black tracking-widest text-white uppercase placeholder-zinc-800 outline-none transition-all duration-200 shadow-inner"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-2">
                Your Player Name
              </label>
              <input
                type="text"
                value={playerName}
                onChange={(e) => setPlayerName(e.target.value.slice(0, 16))}
                placeholder="What should we call you?"
                required
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-indigo-500 rounded-2xl py-4 px-5 text-lg font-bold text-white placeholder-zinc-700 outline-none transition-all duration-200 shadow-inner"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-4 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-black py-4 px-6 rounded-2xl transition-all duration-200 flex items-center justify-center gap-2 group cursor-pointer shadow-lg shadow-indigo-600/20"
            >
              {loading ? 'Entering Lobby...' : 'Join Game'}
              <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </form>
        ) : (
          <form onSubmit={handleCreate} className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-2">
                Your Host Name
              </label>
              <input
                type="text"
                value={hostName}
                onChange={(e) => setHostName(e.target.value.slice(0, 16))}
                placeholder="e.g. Game Master"
                required
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-indigo-500 rounded-2xl py-3 px-4 text-md font-bold text-white placeholder-zinc-800 outline-none transition-all duration-200 shadow-inner"
              />
            </div>

            {/* Game Mode */}
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-2 flex justify-between">
                <span>Game Mode</span>
                <span className="text-indigo-400">Perfect for large groups!</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setGameMode('classic')}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                    gameMode === 'classic'
                      ? 'bg-indigo-600/10 border-indigo-500 text-white'
                      : 'bg-zinc-950 border-zinc-850 text-zinc-400'
                  }`}
                >
                  <div className="font-bold text-sm">Classic mode</div>
                  <div className="text-[10px] text-zinc-500 mt-1">Up to 8 players write lies. Rest are Audience who vote & score.</div>
                </button>
                <button
                  type="button"
                  onClick={() => setGameMode('chaos')}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                    gameMode === 'chaos'
                      ? 'bg-indigo-600/10 border-indigo-500 text-white'
                      : 'bg-zinc-950 border-zinc-850 text-zinc-400'
                  }`}
                >
                  <div className="font-bold text-sm">Chaos mode</div>
                  <div className="text-[10px] text-zinc-500 mt-1">Everyone plays! We randomly sample lies if there are many players.</div>
                </button>
              </div>
            </div>

            {gameMode === 'classic' && (
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-2">
                  Max Active Writers: {maxPlayers}
                </label>
                <input
                  type="range"
                  min="3"
                  max="12"
                  value={maxPlayers}
                  onChange={(e) => setMaxPlayers(parseInt(e.target.value))}
                  className="w-full accent-indigo-500"
                />
                <div className="flex justify-between text-[10px] text-zinc-500 mt-1">
                  <span>3 Players</span>
                  <span>8 (Recommended)</span>
                  <span>12 Players</span>
                </div>
              </div>
            )}

            {/* Question Theme Select */}
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-2 flex items-center justify-between">
                <span>Trivia Category / Prompt</span>
                <span className="text-indigo-400 flex items-center gap-1">
                  <Sparkles size={12} /> Powered by Gemini
                </span>
              </label>
              <div className="space-y-2 max-h-[160px] overflow-y-auto bg-zinc-950 p-2 rounded-2xl border border-zinc-850 pr-1">
                {PRESET_THEMES.map((theme) => (
                  <button
                    key={theme.id}
                    type="button"
                    onClick={() => setSelectedTheme(theme.id)}
                    className={`w-full p-2.5 rounded-xl border text-left transition-all flex justify-between items-center cursor-pointer ${
                      selectedTheme === theme.id
                        ? 'bg-indigo-600/10 border-indigo-500 text-white'
                        : 'border-transparent text-zinc-400 hover:bg-zinc-900'
                    }`}
                  >
                    <div>
                      <div className="font-bold text-xs">{theme.name}</div>
                      <div className="text-[10px] text-zinc-500 mt-0.5">{theme.desc}</div>
                    </div>
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setSelectedTheme('custom')}
                  className={`w-full p-2.5 rounded-xl border text-left transition-all flex justify-between items-center cursor-pointer ${
                    selectedTheme === 'custom'
                      ? 'bg-indigo-600/10 border-indigo-500 text-white'
                      : 'border-transparent text-zinc-400 hover:bg-zinc-900'
                  }`}
                >
                  <div>
                    <div className="font-bold text-xs">✨ Custom Prompt...</div>
                    <div className="text-[10px] text-zinc-500 mt-0.5">Let Gemini write trivia about literally anything!</div>
                  </div>
                </button>
              </div>
            </div>

            {selectedTheme === 'custom' && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-2"
              >
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1.5">
                  Custom Category Prompt
                </label>
                <input
                  type="text"
                  value={customTheme}
                  onChange={(e) => setCustomTheme(e.target.value.slice(0, 100))}
                  placeholder="e.g. Bizarre chemistry facts, Video game history, Inside jokes"
                  required
                  className="w-full bg-zinc-950 border border-zinc-850 focus:border-indigo-500 rounded-xl py-2 px-3 text-sm font-medium text-white placeholder-zinc-700 outline-none"
                />
              </motion.div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-4 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-black py-4 px-6 rounded-2xl transition-all duration-200 flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20 cursor-pointer"
            >
              {loading ? 'Creating Lobby...' : 'Create Room'}
              <ArrowRight size={18} />
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

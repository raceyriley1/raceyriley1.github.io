import React from 'react';
import { Crown, Trophy, RotateCcw, Award, Star, ArrowLeft } from 'lucide-react';
import { motion } from 'motion/react';
import { LobbyState } from '../types.js';

interface GameOverPhaseProps {
  lobby: LobbyState;
  playerId: string;
  onRestartGame: () => void;
  loading?: boolean;
}

export default function GameOverPhase({ lobby, playerId, onRestartGame, loading }: GameOverPhaseProps) {
  const isHost = lobby.hostId === playerId;

  const activePlayers = lobby.players
    .filter((p) => !p.isAudience && p.id !== lobby.hostId)
    .sort((a, b) => b.score - a.score);

  const audiencePlayers = lobby.players
    .filter((p) => p.isAudience && p.id !== lobby.hostId)
    .sort((a, b) => b.audienceScore - a.audienceScore);

  const goldWinner = activePlayers[0];
  const silverWinner = activePlayers[1];
  const bronzeWinner = activePlayers[2];

  const topAudience = audiencePlayers[0];

  return (
    <div className="w-full max-w-2xl mx-auto bg-zinc-900 border border-zinc-800 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden text-zinc-100">
      {/* Decorative fireworks/lights */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Confetti Sparkles Header */}
      <div className="text-center mb-8 relative z-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-black tracking-widest uppercase mb-3 rounded-full animate-bounce">
          <Star size={12} className="fill-amber-400" /> CONGRATULATIONS!
        </div>
        <h2 className="text-5xl font-black text-white tracking-tighter uppercase leading-none">GAME OVER</h2>
        <p className="text-sm text-zinc-400 mt-1.5">Here are the ultimate master fibbers of this session!</p>
      </div>

      {/* The Podium Stand */}
      <div className="bg-zinc-950 border border-zinc-850 p-6 rounded-3xl mb-8 relative z-10 shadow-lg flex flex-col items-center">
        <h3 className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-6 flex items-center gap-1.5">
          <Trophy size={14} className="text-amber-500 animate-pulse" /> THE CHAMPIONS PODIUM
        </h3>

        <div className="flex items-end justify-center gap-3 sm:gap-6 w-full max-w-md pt-6">
          {/* 2nd Place (Silver) */}
          {silverWinner ? (
            <div className="flex-1 flex flex-col items-center animate-fadeIn">
              <div className="text-sm font-bold text-zinc-300 uppercase truncate max-w-[80px] text-center mb-1">
                {silverWinner.name}
              </div>
              <div className="text-[10px] text-zinc-500 font-bold mb-2">
                {silverWinner.score} pts
              </div>
              <div className="w-16 sm:w-20 bg-zinc-800 border-t-2 border-zinc-400 h-20 rounded-t-xl flex flex-col items-center justify-center shadow-lg relative">
                <span className="text-3xl font-black text-zinc-400">2</span>
                <span className="text-[10px] font-black text-zinc-500 uppercase mt-1">Silver</span>
              </div>
            </div>
          ) : (
            <div className="flex-1" />
          )}

          {/* 1st Place (Gold Winner!) */}
          {goldWinner ? (
            <div className="flex-1 flex flex-col items-center animate-fadeIn">
              <Crown className="text-amber-400 fill-amber-400 animate-bounce mb-1" size={28} />
              <div className="text-md font-black text-white uppercase truncate max-w-[100px] text-center mb-1">
                {goldWinner.name}
              </div>
              <div className="text-xs text-indigo-400 font-black mb-2">
                {goldWinner.score} pts
              </div>
              <div className="w-20 sm:w-24 bg-indigo-950 border-t-4 border-amber-500 h-28 rounded-t-xl flex flex-col items-center justify-center shadow-xl relative">
                <span className="text-4xl font-black text-amber-400">1</span>
                <span className="text-[10px] font-black text-amber-400 uppercase mt-1 tracking-wider">GOLD</span>
              </div>
            </div>
          ) : (
            <div className="flex-1" />
          )}

          {/* 3rd Place (Bronze) */}
          {bronzeWinner ? (
            <div className="flex-1 flex flex-col items-center animate-fadeIn">
              <div className="text-sm font-bold text-amber-600/90 uppercase truncate max-w-[80px] text-center mb-1">
                {bronzeWinner.name}
              </div>
              <div className="text-[10px] text-zinc-500 font-bold mb-2">
                {bronzeWinner.score} pts
              </div>
              <div className="w-16 sm:w-20 bg-zinc-800 border-t-2 border-amber-700 h-14 rounded-t-xl flex flex-col items-center justify-center shadow-lg relative">
                <span className="text-3xl font-black text-amber-700">3</span>
                <span className="text-[10px] font-black text-zinc-500 uppercase mt-1">Bronze</span>
              </div>
            </div>
          ) : (
            <div className="flex-1" />
          )}
        </div>
      </div>

      {/* Dedicated Audience Champion Badge */}
      {topAudience && topAudience.audienceScore > 0 && (
        <div className="mb-6 p-4 rounded-2xl bg-amber-500/5 border border-amber-500/25 flex items-center justify-between relative z-10 shadow-inner">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400">
              <Award size={20} />
            </div>
            <div>
              <div className="text-[9px] text-amber-400 font-bold uppercase tracking-widest">Audience Champion</div>
              <div className="text-sm font-black text-white uppercase">{topAudience.name}</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest">Audience Score</div>
            <div className="text-lg font-black text-amber-400 font-mono">{topAudience.audienceScore} pts</div>
          </div>
        </div>
      )}

      {/* Standings List */}
      <div className="space-y-3 mb-8 relative z-10 max-h-[220px] overflow-y-auto pr-1">
        <h4 className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 border-b border-zinc-800 pb-2">
          Full Game Standings
        </h4>
        {activePlayers.map((p, idx) => (
          <div
            key={p.id}
            className="bg-zinc-950/40 border border-zinc-850/80 p-3 rounded-xl flex items-center justify-between text-xs shadow-sm"
          >
            <div className="flex items-center gap-2 truncate">
              <span className="font-mono text-zinc-600 font-black">#{idx + 1}</span>
              <span className="font-bold text-zinc-300 uppercase truncate">{p.name}</span>
            </div>
            <span className="font-black text-white font-mono">{p.score} pts</span>
          </div>
        ))}
      </div>

      {/* Host Restart Controls */}
      <div className="border-t border-zinc-800/85 pt-6 relative z-10">
        {isHost ? (
          <button
            onClick={onRestartGame}
            disabled={loading}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 px-6 rounded-2xl transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/20"
          >
            <RotateCcw size={18} />
            {loading ? 'Setting up...' : 'Play Another Game'}
          </button>
        ) : (
          <div className="text-center p-3.5 bg-zinc-950/40 rounded-xl border border-zinc-850/50 text-xs text-zinc-500 font-bold uppercase tracking-wider animate-pulse">
            Waiting for host to restart a new lobby... Keep your phones connected!
          </div>
        )}
      </div>
    </div>
  );
}

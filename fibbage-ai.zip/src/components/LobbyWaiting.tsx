import React from 'react';
import { Users, Shield, Award, Play, AlertCircle, Laptop } from 'lucide-react';
import { motion } from 'motion/react';
import { LobbyState, Player } from '../types.js';

interface LobbyWaitingProps {
  lobby: LobbyState;
  playerId: string;
  onStartGame: () => void;
  loading?: boolean;
}

export default function LobbyWaiting({ lobby, playerId, onStartGame, loading }: LobbyWaitingProps) {
  const isHost = lobby.hostId === playerId;
  const myPlayer = lobby.players.find((p) => p.id === playerId);
  
  // Sort players: Host first, then active players, then audience
  const hostPlayer = lobby.players.find((p) => p.id === lobby.hostId);
  const activePlayers = lobby.players.filter((p) => !p.isAudience && p.id !== lobby.hostId);
  const audiencePlayers = lobby.players.filter((p) => p.isAudience && p.id !== lobby.hostId);

  return (
    <div className="w-full max-w-2xl mx-auto bg-zinc-900 border border-zinc-800 rounded-3xl p-6 md:p-8 shadow-2xl relative overflow-hidden text-zinc-100">
      {/* Decorative ambient background lights */}
      <div className="absolute top-0 right-1/4 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Join Instructions */}
      <div className="text-center mb-8 relative z-10">
        <div className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-2">
          JOINING INSTRUCTIONS
        </div>
        <div className="bg-zinc-950 p-4 rounded-2xl border border-zinc-800 inline-block mb-4 shadow-inner">
          <p className="text-zinc-400 text-xs font-bold mb-1">GO TO THIS WEB ADDRESS ON YOUR PHONE:</p>
          <p className="text-indigo-400 font-mono text-sm font-black tracking-wide selection:bg-indigo-500/30">
            {window.location.origin}
          </p>
        </div>
        <div className="text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-2">
          AND ENTER ROOM CODE
        </div>
        <div className="inline-flex flex-col items-center justify-center bg-zinc-950 px-8 py-5 rounded-3xl border-2 border-indigo-500 shadow-[0_0_20px_rgba(79,70,229,0.25)] mb-4 animate-bounce">
          <span className="text-6xl font-black text-white tracking-[0.15em] leading-none font-mono pl-[0.15em] select-all">
            {lobby.code}
          </span>
        </div>
        
        {/* Category Details */}
        <div className="text-xs text-zinc-400 mt-2">
          Category/Theme: <span className="text-indigo-400 font-bold">{lobby.categoryTheme}</span>
        </div>
      </div>

      {/* Connection Info */}
      {myPlayer && (
        <div className="mb-6 p-4 rounded-2xl bg-zinc-950/80 border border-zinc-800/80 flex items-center justify-between text-xs font-bold relative z-10 shadow-inner">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
            <span className="text-zinc-400">Connected as:</span>
            <span className="text-white text-sm">{myPlayer.name}</span>
          </div>
          <div>
            {myPlayer.isAudience ? (
              <span className="px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400">
                Audience Member
              </span>
            ) : isHost ? (
              <span className="px-2.5 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 flex items-center gap-1">
                <Shield size={12} /> Host
              </span>
            ) : (
              <span className="px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                Active Player
              </span>
            )}
          </div>
        </div>
      )}

      {/* Players Lists */}
      <div className="space-y-6 mb-8 relative z-10">
        {/* Active Players Grid */}
        <div>
          <h3 className="text-xs font-black uppercase tracking-widest text-zinc-400 mb-3 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Users size={14} className="text-indigo-400" />
              Active Players ({activePlayers.length + (hostPlayer && !hostPlayer.isAudience ? 1 : 0)})
            </span>
            {lobby.gameMode === 'classic' && (
              <span className="text-zinc-500 normal-case font-medium">Max {lobby.maxActivePlayers} active writers</span>
            )}
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {/* Host first */}
            {hostPlayer && (
              <div className="bg-indigo-600/10 border border-indigo-500/30 p-3 rounded-xl flex items-center justify-between shadow-[0_0_15px_rgba(79,70,229,0.15)]">
                <span className="text-sm font-bold text-indigo-300 truncate">{hostPlayer.name}</span>
                <span className="text-[9px] bg-indigo-500/20 text-indigo-300 px-1.5 py-0.5 rounded uppercase font-extrabold flex items-center gap-0.5">
                  <Laptop size={10} /> Host
                </span>
              </div>
            )}
            {/* Active Players */}
            {activePlayers.map((player) => (
              <div
                key={player.id}
                className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                  player.connected 
                    ? 'bg-zinc-950/80 border-zinc-800 text-white' 
                    : 'bg-zinc-950/40 border-zinc-900 text-zinc-600'
                }`}
              >
                <span className="text-sm font-bold truncate">{player.name}</span>
                {!player.connected && (
                  <span className="text-[8px] bg-zinc-850 text-zinc-500 px-1 py-0.5 rounded font-bold uppercase">
                    Offline
                  </span>
                )}
              </div>
            ))}
            {activePlayers.length === 0 && !hostPlayer && (
              <div className="col-span-full py-4 text-center text-xs text-zinc-600 font-bold uppercase tracking-wider animate-pulse">
                Waiting for players to join...
              </div>
            )}
          </div>
        </div>

        {/* Audience Players */}
        {lobby.gameMode === 'classic' && (
          <div>
            <h3 className="text-xs font-black uppercase tracking-widest text-zinc-400 mb-3 flex items-center gap-1.5 border-b border-zinc-800/80 pb-2">
              <Award size={14} className="text-amber-500" />
              Audience ({audiencePlayers.length})
            </h3>
            {audiencePlayers.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 animate-fadeIn">
                {audiencePlayers.map((player) => (
                  <div
                    key={player.id}
                    className="bg-zinc-950/50 border border-zinc-850 p-3 rounded-xl flex items-center justify-between shadow-inner"
                  >
                    <span className="text-sm font-medium text-zinc-300 truncate">{player.name}</span>
                    <span className="text-[8px] bg-amber-500/10 text-amber-400 border border-amber-500/20 px-1.5 py-0.5 rounded font-bold uppercase">
                      Audience
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-zinc-950/30 border border-zinc-850/50 text-center text-xs text-zinc-500 font-medium">
                Once active slots are filled, additional players automatically join the Audience!
              </div>
            )}
          </div>
        )}
      </div>

      {/* Host Control Actions */}
      <div className="relative z-10 border-t border-zinc-800/80 pt-6">
        {isHost ? (
          <div className="space-y-3">
            {lobby.players.length < 3 && (
              <div className="p-3.5 rounded-xl bg-amber-500/5 border border-amber-500/10 text-amber-500 text-xs flex items-center gap-2">
                <AlertCircle size={16} className="shrink-0" />
                <span>You need at least 3 players to start a fun game of Fibbage! Connect more devices using the code above.</span>
              </div>
            )}
            <button
              onClick={onStartGame}
              disabled={loading || lobby.players.length < 2}
              className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed font-black text-white text-lg py-4 px-6 rounded-2xl transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-indigo-600/20"
            >
              {loading ? 'Generating Trivia...' : 'Start Game'}
              <Play size={18} />
            </button>
          </div>
        ) : (
          <div className="text-center p-4 bg-zinc-950/40 rounded-2xl border border-zinc-850/50 text-sm text-zinc-400 font-medium animate-pulse">
            Waiting for the host to start the game... Get ready to lie!
          </div>
        )}
      </div>
    </div>
  );
}

export interface Player {
  id: string;
  name: string;
  score: number;
  audienceScore: number;
  isAudience: boolean;
  connected: boolean;
  submittedThisRound: boolean;
  votedThisRound: boolean;
  fooledCount: number;
  gotTruth: boolean;
  pointsGainedThisRound: number;
}

export interface Question {
  id: string;
  category: string;
  question: string;
  truth: string;
  fallbackLies: string[];
}

export interface Round {
  roundNumber: number;
  question: Question;
  lies: { [playerId: string]: string }; // playerId -> lieText
  votes: { [playerId: string]: string }; // playerId -> chosenOptionText (could be a lie or the truth)
  scoresThisRound: { [playerId: string]: number }; // playerId -> score added
}

export type GameStatus = 'lobby' | 'writing' | 'voting' | 'reveal' | 'scoreboard' | 'gameover';

export interface LobbyState {
  code: string;
  hostId: string;
  status: GameStatus;
  gameMode: 'classic' | 'chaos';
  maxActivePlayers: number;
  players: Player[];
  questions: Question[];
  currentRoundIndex: number;
  timer: number;
  maxTimer: number;
  categoryTheme: string;
  revealState?: {
    currentRevealedIndex: number; // For step-by-step display of lies and who wrote them
    options: string[]; // Shuffled list of options shown
    truthOption: string;
    lies?: { [playerId: string]: string };
    votes?: { [playerId: string]: string };
  };
}

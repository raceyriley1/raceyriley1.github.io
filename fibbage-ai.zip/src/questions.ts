import { Question } from './types.js';

export const FALLBACK_QUESTIONS: Question[] = [
  {
    id: "fb_1",
    category: "Weird Court Cases",
    question: "In 2013, a man in China sued his wife for being ________, and won a $120,000 settlement.",
    truth: "ugly",
    fallbackLies: ["a spy", "poor", "his cousin", "too smart", "an alien", "bad at cooking"]
  },
  {
    id: "fb_2",
    category: "Odd Occupations",
    question: "In 18th-century England, wealthy estate owners would hire 'ornamental ________' to live in their gardens.",
    truth: "hermits",
    fallbackLies: ["scarecrows", "monkeys", "statues", "shepherds", "ghosts", "garden gnomes"]
  },
  {
    id: "fb_3",
    category: "Local Politics",
    question: "For over 20 years, the honorary mayor of the town of Talkeetna, Alaska, was a ________.",
    truth: "cat",
    fallbackLies: ["dog", "golden retriever", "beer bottle", "pine tree", "moose", "teddy bear"]
  },
  {
    id: "fb_4",
    category: "False Advertising",
    question: "In 2015, a man sued the makers of ________ because the product failed to make him attractive to women.",
    truth: "Axe body spray",
    fallbackLies: ["Old Spice", "Nike shoes", "Gatorade", "Red Bull", "Colgate toothpaste", "Ferrero Rocher"]
  },
  {
    id: "fb_5",
    category: "Ancient Punishment",
    question: "Under ancient Roman law, someone convicted of murdering a parent was sewn into a sack with a dog, a rooster, a monkey, and a ________ before being thrown in the water.",
    truth: "snake",
    fallbackLies: ["pig", "cat", "rat", "badger", "scorpio", "lobster"]
  },
  {
    id: "fb_6",
    category: "Wyoming Wonders",
    question: "The entire state of Wyoming, USA, has exactly two ________.",
    truth: "escalators",
    fallbackLies: ["traffic lights", "airports", "starbucks", "elevators", "paved highways", "millionaires"]
  },
  {
    id: "fb_7",
    category: "Victorian Trends",
    question: "In Victorian England, it was a common and popular family tradition to take photos of relatives who were ________.",
    truth: "dead",
    fallbackLies: ["sleeping", "sneezing", "crying", "naked", "eating onions", "covered in mud"]
  },
  {
    id: "fb_8",
    category: "Museums",
    question: "In 2018, Malmö, Sweden opened a unique museum dedicated entirely to ________ food.",
    truth: "disgusting",
    fallbackLies: ["spicy", "blue-colored", "imaginary", "pet", "microwave-only", "overpriced"]
  },
  {
    id: "fb_9",
    category: "Bizarre Space History",
    question: "In 1969, the US government officially made it illegal for citizens to have any contact with ________.",
    truth: "extraterrestrials",
    fallbackLies: ["communists", "the moon", "satellites", "french food", "hippies", "astronauts"]
  },
  {
    id: "fb_10",
    category: "Family Sacrifice",
    question: "To help fund her husband's scientific research, Margrethe Bohr famously sold her family's ________.",
    truth: "Nobel prize medal",
    fallbackLies: ["castle", "dairy farm", "silverware", "piano", "art collection", "yacht"]
  },
  {
    id: "fb_11",
    category: "Ecological Disasters",
    question: "In 1859, Thomas Austin released 24 ________ in Australia for hunting, inadvertently starting an environmental catastrophe.",
    truth: "rabbits",
    fallbackLies: ["foxes", "deer", "rats", "cats", "squirrels", "bullfrogs"]
  },
  {
    id: "fb_12",
    category: "Extreme Flight",
    question: "In 2015, a Canadian man was arrested after flying over Calgary in a lawn chair attached to 110 ________.",
    truth: "helium balloons",
    fallbackLies: ["drones", "leaf blowers", "fireworks", "parachutes", "kites", "pigeons"]
  },
  {
    id: "fb_13",
    category: "Ancient Menus",
    question: "The oldest known written recipe in human history is a 4,000-year-old Sumerian recipe for ________.",
    truth: "beer",
    fallbackLies: ["bread", "pancakes", "lentil soup", "beef stew", "garlic butter", "honey cake"]
  },
  {
    id: "fb_14",
    category: "Bizarre Inventions",
    question: "In 1912, a French inventor died after jumping off the Eiffel Tower while testing his home-made ________.",
    truth: "parachute suit",
    fallbackLies: ["wings", "flying bicycle", "spring boots", "helicopter hat", "glider wings", "jetpack"]
  },
  {
    id: "fb_15",
    category: "Strange Competitions",
    question: "In Finland, there is an official, highly popular annual world championship for carrying your ________.",
    truth: "wife",
    fallbackLies: ["couch", "mother-in-law", "dog", "television", "boss", "logs"]
  },
  {
    id: "fb_16",
    category: "Royal Secrets",
    question: "King Henry VIII of England had a dedicated court position called the 'Groom of the ________', whose job was to help him toilet.",
    truth: "Stool",
    fallbackLies: ["Chamber", "Robes", "Royal Bottom", "Bed", "Sceptre", "Privy"]
  },
  {
    id: "fb_17",
    category: "Banned in Singapore",
    question: "In 1992, Singapore officially banned the import and sale of ________ to keep public spaces clean.",
    truth: "chewing gum",
    fallbackLies: ["soda cans", "balloons", "pigeons", "rollerblades", "plastic bags", "umbrellas"]
  },
  {
    id: "fb_18",
    category: "Odd Laws",
    question: "In Milan, Italy, there is an old law that makes it legally required to ________ at all times, except at funerals or hospitals.",
    truth: "smile",
    fallbackLies: ["sing", "bow", "wear a hat", "whisper", "hold hands", "pay cash"]
  },
  {
    id: "fb_19",
    category: "Military Blunders",
    question: "In 1932, the Australian military fought a war against a flock of 20,000 ________, and actually lost.",
    truth: "emus",
    fallbackLies: ["kangaroos", "rabbits", "pigeons", "wild pigs", "parrots", "dingoes"]
  },
  {
    id: "fb_20",
    category: "Strange Trademarks",
    question: "In 1999, the celebrity singer Prince legally trademarked a specific shade of the color ________.",
    truth: "purple",
    fallbackLies: ["magenta", "gold", "pink", "violet", "black", "lavender"]
  }
];
